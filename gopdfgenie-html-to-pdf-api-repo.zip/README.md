# GoPDFGenie — HTML → PDF/PNG API

Convert **real web pages** to pixel‑accurate **PDF** or **PNG** through a simple, reliable HTTP API. Works with **iframes**, **client-side apps (SPA/React/Vue)**, dynamic JavaScript, and **authenticated pages**.

**Website:** https://gopdfgenie.com  
**API Base:** `https://gopdfgenie.com/api/v1`  
**Interactive Docs (Swagger):** `https://gopdfgenie.com/swagger-ui/index.html`

---

## Overview

1. **Create a job** with `POST /convert/async`, sending either a `url` or raw `html`, plus output options (`pdf` or `png`).  
2. **Poll the job** with `GET /jobs/{id}` until `status` is `succeeded` (or `failed`).  
3. **Download the file** using the short‑lived `downloadUrl` returned in the job response.

---

## Authentication

All requests must include your API key:

```
Authorization: Bearer YOUR_API_KEY
```

Keep your key secret. Rotate it if compromised.

---

## Endpoints

### POST `/convert/async`
Create an asynchronous conversion job.

**Body (JSON):** send **either** `url` **or** `html` plus output options.

```json
{
  "url": "https://example.com/report",
  "wait": { "mode": "networkidle", "timeout": 20000 },
  "pdf":  { "format": "A4", "printBackground": true },
  "fileName": "report.pdf",
  "metadata": { "orderId": "12345" }
}
```

or:

```json
{
  "html": "<!doctype html><html><body><h1>Hello</h1></body></html>",
  "wait": { "mode": "selector", "target": "body" },
  "png":  { "fullPage": true },
  "fileName": "hello.png"
}
```

**Response (JSON):**
```json
{ "id": "job_abc123", "status": "queued", "metadata": { "orderId": "12345" } }
```

---

### GET `/jobs/{id}`
Check job status and get output file links.

**Response (JSON) — success:**
```json
{
  "id": "job_abc123",
  "status": "succeeded",
  "pdf": {
    "downloadUrl": "https://.../file.pdf",
    "pages": 3,
    "sizeBytes": 123456,
    "expiresAt": "2025-12-01T10:20:30Z"
  },
  "png": null,
  "metadata": { "orderId": "12345" }
}
```

> `downloadUrl` is usually time‑limited. Save the file promptly.

**Response (JSON) — failure:**
```json
{
  "id": "job_abc123",
  "status": "failed",
  "error": { "code": "RENDER_TIMEOUT", "message": "Page did not become ready in 20000 ms." }
}
```

---

## Request Body Reference

Send **either** `url` **or** `html`. Optional keys are shown with examples.

```json
{
  "url": "https://example.com/page",          // OR "html": "<!doctype html>..."
  "headers": { "Cookie": "session=...", "Authorization": "Bearer app-token" },

  "wait": {
    "mode": "networkidle",                    // or "selector"
    "timeout": 20000,                         // ms (optional)
    "target": "#ready"                        // required when mode = "selector"
  },

  "pdf": {
    "format": "A4",
    "printBackground": true,
    "landscape": false,
    "scale": 1.0,                             // 0.1–2.0
    "margin": { "top": "16mm", "bottom": "16mm", "left": "16mm", "right": "16mm" },
    "pageRanges": "1-3,7"
  },

  "png": {
    "fullPage": true,
    "scale": 1.0,                             // 0.1–2.0
    "clip": { "x": 0, "y": 0, "width": 1200, "height": 800 }
  },

  "fileName": "my-output.pdf",
  "webhookUrl": "https://example.com/hooks/pdf-finished",   // if enabled on your plan
  "metadata": { "orderId": "12345" }                        // echoed back on job
}
```

### Wait Modes
- `"networkidle"` — proceed when the page becomes idle (good for dashboards and data‑heavy pages).
- `"selector"` — proceed when a specific element is present; set `"target"` to a CSS selector.

### PDF Options
- `format`: page size (`A4`, `Letter`, etc.)
- `printBackground`: include CSS backgrounds
- `landscape`: orientation
- `scale`: zoom (0.1–2.0)
- `margin`: `{ top, right, bottom, left }` (supports `mm`, `in`, `px`)
- `pageRanges`: e.g. `"1-2,5"`

### PNG Options
- `fullPage`: capture entire scroll height
- `scale`: zoom
- `clip`: crop rectangle `{ x, y, width, height }` (optional)

### Headers (for auth pages)
Send cookies or auth headers the target page requires:
```json
"headers": {
  "Cookie": "session=abc123; other=value",
  "Authorization": "Bearer your-app-token"
}
```

---

## End‑to‑End Examples

### cURL (URL → PDF)
```bash
curl -X POST "https://gopdfgenie.com/api/v1/convert/async"   -H "Authorization: Bearer $GOPDFGENIE_API_KEY"   -H "Content-Type: application/json"   -d '{
    "url": "https://example.com/dashboard",
    "wait": { "mode": "networkidle", "timeout": 20000 },
    "pdf":  { "format": "A4", "printBackground": true },
    "fileName": "dashboard.pdf"
  }'
# => { "id": "job_..." }

# Poll
curl -H "Authorization: Bearer $GOPDFGENIE_API_KEY"   "https://gopdfgenie.com/api/v1/jobs/job_..."

# Download (once succeeded and you have the URL)
curl -o output.pdf "https://.../download-url-from-job"
```

### cURL (HTML → PDF)
```bash
curl -X POST "https://gopdfgenie.com/api/v1/convert/async"   -H "Authorization: Bearer $GOPDFGENIE_API_KEY"   -H "Content-Type: application/json"   -d '{
    "html": "<!doctype html><html><body><h1>Hello PDF</h1></body></html>",
    "wait": { "mode": "selector", "target": "body" },
    "pdf":  { "format": "A4", "margin": { "top":"16mm","bottom":"16mm" } },
    "fileName": "hello.pdf"
  }'
```

### Java (stdlib only)
See `examples/java/HtmlToPdfExample.java` for a full, runnable example.

### Node.js
See `examples/node/convert.js` (Node 18+ with built‑in `fetch`).

### Python
See `examples/python/convert.py` (uses `requests`).

---

## Errors

| HTTP | Example Code         | Meaning / Fix                                                |
|-----:|----------------------|--------------------------------------------------------------|
| 400  | `INVALID_BODY`       | Missing `url`/`html` or invalid options.                    |
| 401  | `UNAUTHORIZED`       | Missing or invalid API key.                                 |
| 403  | `PLAN_RESTRICTED`    | Over size/feature limits for your plan.                     |
| 404  | `JOB_NOT_FOUND`      | Wrong job ID.                                               |
| 429  | `RATE_LIMITED`       | Too many requests / quota exhausted.                        |
| 5xx  | `INTERNAL_ERROR`     | Temporary issue; retry with exponential backoff.            |

Failed job payload:
```json
{
  "id": "job_abc123",
  "status": "failed",
  "error": { "code": "RENDER_TIMEOUT", "message": "Page did not become ready in time." }
}
```

---

## Rate Limits & Credits

- Usage is **1 credit per 10 MB of output** (rounded up).  
- Plans: Free, Starter, Pro, Business; on‑prem & enterprise available.  
- Pricing: https://gopdfgenie.com/pricing

---

## License

Examples in this repository are provided under **Apache‑2.0**. See `LICENSE`.
