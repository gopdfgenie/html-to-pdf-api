import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;

/**
 * Minimal Java example:
 * 1) Submit a conversion job  2) Poll status  3) Download the PDF
 * Requires Java 11+ (uses java.net.http).
 */
public class HtmlToPdfExample {
    static final String API_BASE = "https://gopdfgenie.com/api/v1";
    static final String API_KEY  = System.getenv("GOPDFGENIE_API_KEY");

    public static void main(String[] args) throws Exception {
        if (API_KEY == null || API_KEY.isEmpty()) {
            throw new IllegalStateException("Set env var GOPDFGENIE_API_KEY");
        }

        HttpClient http = HttpClient.newBuilder()
                .connectTimeout(Duration.ofSeconds(20))
                .build();

        // 1) Submit conversion job (URL → PDF)
        String payload = """

        {

          "url": "https://example.com/dashboard",

          "wait": { "mode": "networkidle", "timeout": 20000 },

          "pdf":  { "format": "A4", "printBackground": true },

          "fileName": "dashboard.pdf"

        }

        """;

        HttpRequest submit = HttpRequest.newBuilder()
                .uri(URI.create(API_BASE + "/convert/async"))
                .timeout(Duration.ofSeconds(30))
                .header("Authorization", "Bearer " + API_KEY)
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(payload))
                .build();

        HttpResponse<String> submitRes = http.send(submit, HttpResponse.BodyHandlers.ofString());
        if (submitRes.statusCode() >= 300) {
            throw new RuntimeException("Submit failed: " + submitRes.body());
        }

        String jobId = extract(submitRes.body(), "id");
        System.out.println("Job: " + jobId);

        // 2) Poll
        String downloadUrl = null;
        for (int i = 0; i < 60; i++) {
            Thread.sleep(2000);
            HttpRequest poll = HttpRequest.newBuilder()
                    .uri(URI.create(API_BASE + "/jobs/" + jobId))
                    .timeout(Duration.ofSeconds(20))
                    .header("Authorization", "Bearer " + API_KEY)
                    .GET()
                    .build();
            HttpResponse<String> pollRes = http.send(poll, HttpResponse.BodyHandlers.ofString());
            if (pollRes.statusCode() >= 300) throw new RuntimeException("Poll failed: " + pollRes.body());
            String status = extract(pollRes.body(), "status");
            if ("succeeded".equals(status)) {
                downloadUrl = extractNested(pollRes.body(), "pdf", "downloadUrl");
                break;
            }
            if ("failed".equals(status)) {
                throw new RuntimeException("Conversion failed: " + pollRes.body());
            }
        }
        if (downloadUrl == null) throw new RuntimeException("Timeout waiting for job");

        // 3) Download
        HttpRequest dl = HttpRequest.newBuilder(URI.create(downloadUrl)).GET().build();
        HttpResponse<byte[]> fileRes = http.send(dl, HttpResponse.BodyHandlers.ofByteArray());
        if (fileRes.statusCode() >= 300) throw new RuntimeException("Download failed: " + fileRes.statusCode());
        Files.write(Path.of("output.pdf"), fileRes.body());
        System.out.println("Saved → output.pdf");
    }

    // Minimal helpers — replace with Jackson/Gson in real apps
    static String extract(String json, String key) {
        String needle = """ + key + """;
        int i = json.indexOf(needle);
        if (i < 0) return null;
        int colon = json.indexOf(":", i);
        int start = json.indexOf('"', colon + 1) + 1;
        int end = json.indexOf('"', start);
        return (start > 0 && end > start) ? json.substring(start, end) : null;
    }

    static String extractNested(String json, String obj, String key) {
        int i = json.indexOf(""" + obj + """);
        if (i < 0) return null;
        int s = json.indexOf("{", i);
        int e = json.indexOf("}", s);
        return extract(json.substring(s, e + 1), key);
    }
}
