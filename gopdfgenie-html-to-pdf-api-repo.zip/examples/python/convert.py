# Python 3.x example (requires: pip install requests)
# Usage:
#   export GOPDFGENIE_API_KEY=sk_...
#   python examples/python/convert.py

import os, time, json, requests, pathlib

API = 'https://gopdfgenie.com/api/v1'
KEY = os.environ.get('GOPDFGENIE_API_KEY')
if not KEY:
    raise SystemExit('Set env var GOPDFGENIE_API_KEY')

H = {'Authorization': f'Bearer {KEY}', 'Content-Type': 'application/json'}

# 1) submit
payload = {
  "url": "https://example.com/report",
  "wait": {"mode": "selector", "target": "#ready"},
  "pdf": {"format": "A4", "printBackground": True},
  "fileName": "report.pdf"
}
r = requests.post(f"{API}/convert/async", headers=H, data=json.dumps(payload))
r.raise_for_status()
job = r.json()
print("Job:", job["id"])

# 2) poll
download_url = None
for _ in range(60):
    time.sleep(2)
    j = requests.get(f"{API}/jobs/{job['id']}", headers=H).json()
    if j["status"] == "succeeded":
        download_url = (j.get("pdf") or {}).get("downloadUrl") or (j.get("png") or {}).get("downloadUrl")
        break
    if j["status"] == "failed":
        raise SystemExit(f"Job failed: {j['error']}")

if not download_url:
    raise SystemExit("Timeout waiting for job")

# 3) download
b = requests.get(download_url).content
pathlib.Path("output.pdf").write_bytes(b)
print("Saved → output.pdf")
