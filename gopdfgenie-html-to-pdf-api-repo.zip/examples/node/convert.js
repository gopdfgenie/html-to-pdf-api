// Node 18+ (uses built-in fetch). Save as examples/node/convert.js
// Usage:
//   export GOPDFGENIE_API_KEY=sk_...
//   node examples/node/convert.js

import fs from 'node:fs';

const API = 'https://gopdfgenie.com/api/v1';
const KEY = process.env.GOPDFGENIE_API_KEY;
if (!KEY) {
  console.error('Set env var GOPDFGENIE_API_KEY'); process.exit(1);
}
const H = {
  'Authorization': `Bearer ${KEY}`,
  'Content-Type': 'application/json'
};

// 1) Submit
const submitRes = await fetch(`${API}/convert/async`, {
  method: 'POST',
  headers: H,
  body: JSON.stringify({
    url: 'https://example.com/report',
    wait: { mode: 'networkidle', timeout: 20000 },
    pdf: { format: 'A4', printBackground: true },
    fileName: 'report.pdf'
  })
});
if (!submitRes.ok) {
  console.error('Submit failed', await submitRes.text());
  process.exit(1);
}
const job = await submitRes.json();
console.log('Job:', job.id);

// 2) Poll
let downloadUrl = null;
for (let i = 0; i < 60; i++) {
  await new Promise(r => setTimeout(r, 2000));
  const res = await fetch(`${API}/jobs/${job.id}`, { headers: H });
  if (!res.ok) { console.error('Poll failed', await res.text()); process.exit(1); }
  const j = await res.json();
  if (j.status === 'succeeded') {
    downloadUrl = j.pdf?.downloadUrl || j.png?.downloadUrl;
    break;
  }
  if (j.status === 'failed') {
    console.error('Job failed', j.error); process.exit(1);
  }
}
if (!downloadUrl) { console.error('Timeout'); process.exit(1); }

// 3) Download
const fileRes = await fetch(downloadUrl);
if (!fileRes.ok) { console.error('Download failed'); process.exit(1); }
const buf = Buffer.from(await fileRes.arrayBuffer());
fs.writeFileSync('output.pdf', buf);
console.log('Saved → output.pdf');
